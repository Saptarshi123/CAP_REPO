package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.dto.Trainee;

public interface Service {

	public List<Trainee> retrieveAll();

	public int modify(Trainee t);

	public void delete(String id);

	public Trainee show(String id);

	public int add(Trainee t);

}
