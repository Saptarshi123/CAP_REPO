package com.cg.trainee.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.trainee.dao.DAO;
import com.cg.trainee.dao.DAOImpl;
import com.cg.trainee.dto.Trainee;

public class ServiceImpl implements Service{
	ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
	DAO dao = (DAOImpl)appContext.getBean("DAOImpl");
	
	@Override
	public List<Trainee> retrieveAll(){
		return dao.retrieveAll();
	}
	@Override
	public int modify(Trainee t){
		return dao.modify(t);
	}
	@Override
	public void delete(String id){
		dao.delete(id);
	}
	@Override
	public Trainee show(String id){
		return dao.show(id);
	}
	@Override
	public int add(Trainee t){
		return dao.add(t);
	}
}
