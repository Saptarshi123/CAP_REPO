package com.cg.trainee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.trainee.dto.Trainee;

public class DAOImpl implements DAO{
	@Override
	public int add(Trainee t){
		String query = "INSERT INTO trainees VALUES(?,?,?,?)";
		Connection conn = null;
		PreparedStatement pst = null;
		
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username="system";
		String password = "Capgemini123";
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		int records = 0;
		
		try {
			Class.forName(driver);
		
		
		conn = DriverManager.getConnection(url, username, password);
		pst = conn.prepareStatement(query);
		
		pst.setString(1, t.getTraineeId());
		pst.setString(2, t.getTraineeName());
		pst.setString(3, t.getTraineeLocation());
		pst.setString(4, t.getTraineeDomain());
		
		records = pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*simpleJdbcTemplate.update(query,rollNo,name,m1,m2,total,percent);*/
		return records;
	}
	@Override
	public Trainee show(String id){
		String query = "select * from trainees where traineeId=?";
		Connection conn = null;
		PreparedStatement pst = null;
		Trainee t=new Trainee();
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username="system";
		String password = "Capgemini123";
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		try {
			Class.forName(driver);
		
		
		conn = DriverManager.getConnection(url, username, password);
		pst = conn.prepareStatement(query);
		
		pst.setString(1,id);
		
		ResultSet rs=pst.executeQuery();
		if(rs.next()){
			t.setTraineeId(rs.getString(1));
			t.setTraineeName(rs.getString(2));
			t.setTraineeLocation(rs.getString(3));
			t.setTraineeDomain(rs.getString(4));
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}
	@Override
	public void delete(String id){
		String query = "delete from trainees where traineeId=?";
		Connection conn = null;
		PreparedStatement pst = null;
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username="system";
		String password = "Capgemini123";
		String driver = "oracle.jdbc.driver.OracleDriver";
		
		try {
			Class.forName(driver);
		
		
		conn = DriverManager.getConnection(url, username, password);
		pst = conn.prepareStatement(query);
		
		pst.setString(1,id);
		
		pst.executeQuery();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public int modify(Trainee t){
		String query = "delete from trainees where traineeId=?";
		String query1 = "INSERT INTO trainees VALUES(?,?,?,?)";
		Connection conn = null;
		PreparedStatement pst = null;
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username="system";
		String password = "Capgemini123";
		String driver = "oracle.jdbc.driver.OracleDriver";
		int records=0;
		try {
			Class.forName(driver);
		
		
		conn = DriverManager.getConnection(url, username, password);
		pst = conn.prepareStatement(query);
		
		pst.setString(1,t.getTraineeId());
		
		pst.executeQuery();
		
		pst = conn.prepareStatement(query1);
		
		pst.setString(1, t.getTraineeId());
		pst.setString(2, t.getTraineeName());
		pst.setString(3, t.getTraineeLocation());
		pst.setString(4, t.getTraineeDomain());
		
		records = pst.executeUpdate();
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return records;
	}
	@Override
	public List<Trainee> retrieveAll(){
		String query = "select * from trainees";
		Connection conn = null;
		Statement st = null;
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		String username="system";
		String password = "Capgemini123";
		String driver = "oracle.jdbc.driver.OracleDriver";
		List<Trainee> trainees=new ArrayList<>();
		try {
			Class.forName(driver);
		
		
		conn = DriverManager.getConnection(url, username, password);
		st = conn.createStatement();
		
		ResultSet rs=st.executeQuery(query);
		while(rs.next()){
			Trainee t=new Trainee();
			t.setTraineeId(rs.getString(1));
			t.setTraineeName(rs.getString(2));
			t.setTraineeLocation(rs.getString(3));
			t.setTraineeDomain(rs.getString(4));
			trainees.add(t);
		}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return trainees;
	}
}
