package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.dto.Trainee;

public interface DAO {

	public List<Trainee> retrieveAll();
	public int modify(Trainee t);
	public void delete(String id);
	public Trainee show(String id);
	public int add(Trainee t);

}
