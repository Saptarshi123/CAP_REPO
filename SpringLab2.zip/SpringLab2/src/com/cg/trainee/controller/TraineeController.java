package com.cg.trainee.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.Service;
import com.cg.trainee.service.ServiceImpl;

@Controller
public class TraineeController {
	private Service service=new ServiceImpl();
	
	@RequestMapping("/traineeController")
	public ModelAndView handleRequest(HttpServletRequest request,HttpServletResponse response){
	String username=(String)request.getParameter("username");
	String password=(String)request.getParameter("password");
	
		if(username.equals("saptarshi")&&password.equals("saptarshi")){
			ModelAndView modelAndView = new ModelAndView("traineeMgmt");
			return modelAndView;
		}
		else return null;
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ModelAndView add(@RequestParam(value="id", required=true) String id,
				@RequestParam(value="name", required=true) String name,
				@RequestParam(value="loc", required=true) String location,
				@RequestParam(value="domain", required=true) String domain
				){
			
		Trainee trainee=new Trainee();
		trainee.setTraineeId(id);
		trainee.setTraineeName(name);
		trainee.setTraineeLocation(location);
		trainee.setTraineeDomain(domain);
		
		int res=service.add(trainee);
		ModelAndView modelAndView = new ModelAndView("result");
		if(res==0){
			modelAndView.addObject("result","Not Added");
			return modelAndView;
		}
		else {
			modelAndView.addObject("message","Successfully Added");
			return modelAndView;
		}
	}
	
	@RequestMapping(value="/show",method=RequestMethod.POST)
	public ModelAndView show(@RequestParam(value="id", required=true) String id){
		
	
	Trainee trainee=service.show(id);
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("delete");
	modelAndView.addObject("trainee",trainee);
	//("redirect:/viewemp")
		return modelAndView;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public ModelAndView delete(@RequestParam(value="id", required=true) String id){
		
	
	service.delete(id);
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("result");
	modelAndView.addObject("message","Successfully Deleted");
	return modelAndView;
	}
	
	@RequestMapping(value="/mshow",method=RequestMethod.POST)
	public ModelAndView mshow(@RequestParam(value="id", required=true) String id){
		
	
	Trainee trainee=service.show(id);
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("modify");
	modelAndView.addObject("trainee",trainee);
	//("redirect:/viewemp")
		return modelAndView;
	}
	
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public ModelAndView modify(@RequestParam(value="id", required=true) String id,
			@RequestParam(value="name", required=true) String name,
			@RequestParam(value="loc", required=true) String location,
			@RequestParam(value="domain", required=true) String domain
			){
		
	Trainee trainee=new Trainee();
	
		trainee.setTraineeId(id);
		trainee.setTraineeName(name);
		trainee.setTraineeLocation(location);
		trainee.setTraineeDomain(domain);
		
	@SuppressWarnings("unused")
	int res=service.modify(trainee);
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("result");
	modelAndView.addObject("message","Successfully Modified");
	return modelAndView;
	}

	@RequestMapping(value="/retrieve",method=RequestMethod.POST)
	public ModelAndView retrieve(@RequestParam(value="id", required=true) String id){
		
	
	Trainee trainee=service.show(id);
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("retrieve");
	modelAndView.addObject("trainee",trainee);
	//("redirect:/viewemp")
		return modelAndView;
	}
	
	@RequestMapping(value="/retrieveAll",method=RequestMethod.GET)
	public ModelAndView retrieveAll(){
	List<Trainee> trainees=service.retrieveAll();	
	//int res=service.add(trainee);
	ModelAndView modelAndView = new ModelAndView("retrieveall");
	modelAndView.addObject("trainees",trainees);
	return modelAndView;
	}
}
