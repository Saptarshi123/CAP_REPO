package com.cg.dao;

import java.util.List;
import com.cg.entities.TimeSheet;


public interface ITimeSheetDAO {
	
	public void addTimeSheet(TimeSheet timeSheet);
	public List<TimeSheet> getTimeSheetById(String id);

}
