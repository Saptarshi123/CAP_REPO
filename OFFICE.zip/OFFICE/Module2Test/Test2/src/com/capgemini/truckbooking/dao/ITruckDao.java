package com.capgemini.truckbooking.dao;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
public interface ITruckDao {
	int getBookingId() throws BookingException;
	List<TruckBean> retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingbean) throws BookingException;
	int updateTrucks(int truckId,int noOfTruckToBook)throws BookingException;
}
