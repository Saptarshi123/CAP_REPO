package com.capgemini.truckbooking.service;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService implements ITruckService {
	ITruckDao truckDao=new TruckDao();
	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		return truckDao.bookTrucks(bookingBean);
	}

	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook)throws BookingException {
		return (truckDao.updateTrucks(truckId, noOfTruckToBook));
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		return (truckDao.retrieveTruckDetails());
	}
	
}
