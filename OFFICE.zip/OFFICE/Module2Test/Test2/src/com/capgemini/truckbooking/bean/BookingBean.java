package com.capgemini.truckbooking.bean;

import java.time.LocalDate;

public class BookingBean {
	private int bookingId;
	private String custId;
	private long custMobile;
	private int truckId;
	private int noofTrucks;
	private LocalDate dateOfTransport;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public long getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(long custMobile) {
		this.custMobile = custMobile;
	}
	public int getTruckId() {
		return truckId;
	}
	public void setTruckId(int truckId) {
		this.truckId = truckId;
	}
	public int getNoofTrucks() {
		return noofTrucks;
	}
	public void setNoofTrucks(int noofTrucks) {
		this.noofTrucks = noofTrucks;
	}
	public LocalDate getDateOfTransport() {
		return dateOfTransport;
	}
	public void setDateOfTransport(LocalDate dateOfTransport) {
		this.dateOfTransport = dateOfTransport;
	}
	
	
	public BookingBean() {
		super();
	}
	public BookingBean(String custId, long custMobile,
			int truckId, int noofTrucks, LocalDate dateOfTransport) {
		super();
		this.custId = custId;
		this.custMobile = custMobile;
		this.truckId = truckId;
		this.noofTrucks = noofTrucks;
		this.dateOfTransport = dateOfTransport;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", custId=" + custId
				+ ", custMobile=" + custMobile + ", truckId=" + truckId
				+ ", noofTrucks=" + noofTrucks + ", dateOfTransport="
				+ dateOfTransport + "]";
	}
	
	
}
