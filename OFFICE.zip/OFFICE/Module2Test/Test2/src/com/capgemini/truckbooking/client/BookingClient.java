package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {

	public static void main(String[] args) {
		ITruckService truckService=new TruckService();
		BookingBean bookingBean=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Book Trucks\n2. Exit");
		int userchoice=sc.nextInt();
		switch(userchoice)
		{
		case 1:	
		System.out.println("Enter CustId");
		String custId=sc.next();
					
					//CustomerID validation
		if(!custId.matches("[A-Z][0-9]{1,6}"))
		System.out.println("Enter valid CustId");
		else
		{
		try 
		{
			List<TruckBean> truck=truckService.retrieveTruckDetails();
			for(TruckBean tb: truck)
			{
			System.out.println(tb.getTruckId()+" "+tb.getOrigin()+" "+tb.getDestination()+" "+tb.getCharges()+" "+tb.getAvailableNos());
			}
			System.out.println("Enter a valid TruckId");
			int truckId=sc.nextInt();
			System.out.println("No of trucks to be booked");
			int noOfTrucks=sc.nextInt();
			if(noOfTrucks<=0)
			throw new BookingException("Please enter valid no of trucks");
			System.out.println("Enter customer mobile : ");
			String mob=sc.next();
			if(!mob.matches("[0-9]{10}"))
			throw new BookingException("Please enter valid mobile number");
			long mobile=Long.parseLong(mob);
			System.out.println("Enter date of transportation");
			LocalDate date=LocalDate.parse(sc.next());	
						//validation
			if(date.compareTo(LocalDate.now())<1)
			{
			throw new BookingException("Enter valid date");
				}
			bookingBean=new BookingBean(custId,mobile,truckId,noOfTrucks,date);
			int bookingId=truckService.bookTrucks(bookingBean);
			truckService.updateTrucks(bookingBean.getTruckId(), bookingBean.getNoofTrucks());
			System.out.println("Thank You. Your booking id is "+bookingId);
			} 
			catch (BookingException ee)
			{
			System.out.println(ee.getMessage());
				}
			}
			break;
		case 2:	break;		
		}
		sc.close();
	}

}
