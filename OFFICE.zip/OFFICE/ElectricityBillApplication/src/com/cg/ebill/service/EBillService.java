package com.cg.ebill.service;

import java.util.ArrayList;

import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.BillException;

public interface EBillService {
	
	public int insertBillDetails(BillDTO bill) throws BillException;
	public ConsumerDTO selectConsumerDetails(String conNo) throws BillException ;
	public ArrayList<ConsumerDTO> listConsumers() throws BillException;
	public ArrayList<BillDTO> selectBillDetails(String conNo) throws BillException;

}
