package com.cg.ebill.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.cg.ebill.dto.BillDTO;
import com.cg.ebill.dto.ConsumerDTO;
import com.cg.ebill.exception.BillException;
import com.cg.ebill.utility.DBUtil;

public class EBillDaoImpl implements EBillDAO{

	@Override
	public int insertBillDetails(BillDTO bill) throws BillException {
			int billid=0;
		Connection con= DBUtil.createConnection();
		String sql="insert into billdetails(bill_num,consumer_num,cur_reading,"
				+ "unitConsumed,netAmount,bill_date)"
				+ " values(seq_bill_num.nextval,?,?,?,?,sysdate)";
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(bill.getConsumerNo()));
			ps.setDouble(2, bill.getCurrentReading());
			ps.setDouble(3, bill.getUnitsConsumed());
			ps.setDouble(4, bill.getNetAmount());
			
			int r= ps.executeUpdate();
				if(r==1)
				{
					Statement s= con.createStatement();
					ResultSet rs= s.executeQuery("select seq_bill_num.currval from dual");
					if(rs.next())
						return rs.getInt(1);
				}
				
		} catch (SQLException e) {
			if(e.getErrorCode()==2291)
				throw new BillException("Invalid Consumer Number" );
			else
			throw new BillException(e.getMessage());
		}
		
		return billid;
	}

	@Override
	public ConsumerDTO selectConsumerDetails(String conNo) throws BillException {

		ConsumerDTO consumer=null;
		Connection con= DBUtil.createConnection();		
		String query= "select * from consumers where consumer_num=?";
		try {
			consumer=new ConsumerDTO();
			PreparedStatement ps= con.prepareStatement(query);
			ps.setString(1, conNo);
			ResultSet rs= ps.executeQuery();
			if(rs.next()){
				consumer.setConsumerName(rs.getString(1));
				consumer.setConsumerNo(rs.getString(2));
				consumer.setAddress(rs.getString(3));
			}
			else
				throw new BillException("Consumer No Does not Exist");
		} catch (SQLException e) {
				throw new BillException(e.getMessage());
		}		
		return consumer;
	}

	@Override
	public ArrayList<BillDTO> selectBillDetails(String conNo)
			throws BillException {
		
		ArrayList<BillDTO> list= new ArrayList<>();
		String sql= "Select * from billDetails where consumer_num=?";
		try {
			Connection con= DBUtil.createConnection();
			PreparedStatement st= con.prepareStatement(sql);
			st.setString(1, conNo);
			ResultSet rs= st.executeQuery();
				while(rs.next()){
					
					BillDTO bill= new BillDTO();
						bill.setBillNo(rs.getString(1));
						bill.setConsumerNo(rs.getString(2));
						bill.setCurrentReading(rs.getDouble(3));
						bill.setUnitsConsumed(rs.getDouble(4));
						bill.setNetAmount(rs.getDouble(5));
						Date dt= rs.getDate(6);
						bill.setBillDate(dt.toLocalDate());
						list.add(bill);
				}
					
		} catch (SQLException e) {

			throw new BillException(e.getMessage());
		}
return list;
	}

	@Override
	public ArrayList<ConsumerDTO> listConsumers() throws BillException {
			ArrayList<ConsumerDTO> list= new ArrayList<>();
			Connection con= DBUtil.createConnection();
			String  sql= "select * from Consumers";
			try {
				Statement st= con.createStatement();
				ResultSet rs= st.executeQuery(sql);
			while(rs.next()){
				ConsumerDTO bean= new ConsumerDTO();
				bean.setConsumerName(rs.getString("consumer_name"));
				bean.setConsumerNo(rs.getString("consumer_num"));
				bean.setAddress(rs.getString("address"));
				list.add(bean);
			}
			} catch (SQLException e) {
					throw new BillException(e.getMessage());
			}
	return list;
}
}









