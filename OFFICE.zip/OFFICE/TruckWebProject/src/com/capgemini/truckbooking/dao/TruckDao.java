package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.utility.DBUtil;

public class TruckDao implements ITruckDao{
	
	//Booking Id generation
	@Override
	public int getBookingId() throws BookingException {
		Connection conn=null;
		Statement stmt=null;
		int bookingId=0;
		try {
			conn=DBUtil.createConnection();
			stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select booking_id_seq.nextval from dual");
			if(rs.next()){
				bookingId=rs.getInt(1);
			}
			conn.close();
		} catch (SQLException e) {
			throw new BookingException("Problem in BookingId generation");
		}
		return bookingId;
	}
	
	//Retreieving Truck Details
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		List<TruckBean> list=null;
		Connection conn=null;
		Statement stmt=null;
		
		try {
			list=new ArrayList<>();
			conn=DBUtil.createConnection();
			stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from truckdetails");
			while(rs.next()){
				list.add(new TruckBean(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getInt(6)));
			}
			conn.close();
		} catch (SQLException e) {
			throw new BookingException("Problem in view truck details");
		}
		return list;
	}

	//Booking Trucks after checking for availability
	@Override
	public int bookTrucks(BookingBean bookingbean) throws BookingException {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String	sql="select truckId from TruckDetails where truckId=? and availableNos>=?";
		try {
			conn=DBUtil.createConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, bookingbean.getTruckId());
			bookingbean.setBookingId(getBookingId());
			pstmt.setInt(2, bookingbean.getNoofTrucks());
			rs=pstmt.executeQuery();
			if(!rs.next())
				throw new BookingException("Truck not available");
			String sql2="insert into bookingdetails values(?,?,?,?,?,?)";
			pstmt=conn.prepareStatement(sql2);
			pstmt.setInt(1, bookingbean.getBookingId());
			pstmt.setString(2, bookingbean.getCustId());
			pstmt.setLong(3, bookingbean.getCustMobile());
			pstmt.setInt(4, bookingbean.getTruckId());
			pstmt.setInt(5, bookingbean.getNoofTrucks());
			pstmt.setDate(6,Date.valueOf(bookingbean.getDateOfTransport()));
			int status1=pstmt.executeUpdate();
			conn.close();
			return bookingbean.getBookingId();
		} catch (SQLException e) {
			throw new BookingException("Problem in insertion");
		}
	}

	//Updation in trucks quantity after successful booking
	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String	sql="update truckdetails set availableNos=availableNos-? where truckId=?";
		try {
			conn=DBUtil.createConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, noOfTruckToBook);
			
			pstmt.setInt(2,truckId);
			rs=pstmt.executeQuery();
			conn.close();
		} catch (SQLException e) {
			System.out.println("Problem in updation");
		}
		return 1;
	}

}
