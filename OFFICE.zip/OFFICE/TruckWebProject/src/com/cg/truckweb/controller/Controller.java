package com.cg.truckweb.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ITruckService service=new TruckService();
		String action=request.getParameter("action");
		switch(action){
		case "1":	try {
					ArrayList<TruckBean> list=(ArrayList<TruckBean>) service.retrieveTruckDetails();
					request.setAttribute("TruckList", list);
					RequestDispatcher rs=request.getRequestDispatcher("Show_TruckList.jsp");
					rs.forward(request, response);
					} catch (BookingException e) {
						RequestDispatcher rs=request.getRequestDispatcher("Error.jsp");
						request.setAttribute("Error", e.getMessage());
						rs.forward(request, response);
					}
					break;
		
		case "2":	BookingBean bookingBean=null;
					try{
					String custId=request.getParameter("custId");
					String truckId=request.getParameter("truckId");
					String noOfTrucks=request.getParameter("truckNo");
					String mobNo=request.getParameter("mobNo");
					String dateOfTransport=request.getParameter("dateOfTransport");
					if(!custId.matches("[A-Z][0-9]{1,6}"))
						throw new BookingException("Enter valid CustId");
					if(Integer.parseInt(noOfTrucks)<=0)
						throw new BookingException("Please enter valid no of trucks");
					if(!mobNo.matches("[0-9]{10}"))
							throw new BookingException("Please enter valid mobile number");
					LocalDate date=LocalDate.parse(dateOfTransport);
					//Date of transportation validation
					if(date.compareTo(LocalDate.now())<1){
						throw new BookingException("Enter valid date");
					}
					bookingBean=new BookingBean(custId,Long.parseLong(mobNo),Integer.parseInt(truckId),Integer.parseInt(noOfTrucks),date);
					int bookingId=service.bookTrucks(bookingBean);
					service.updateTrucks(bookingBean.getTruckId(), bookingBean.getNoofTrucks());
					request.setAttribute("BookingId", bookingId);
					RequestDispatcher rs=request.getRequestDispatcher("Success.jsp");
					rs.forward(request, response);
					} catch (BookingException e) {
						RequestDispatcher rs=request.getRequestDispatcher("Error.jsp");
						request.setAttribute("Error", e.getMessage());
						rs.forward(request, response);
					}
					break;
		
		}
	}

}
